package redesApp;

import redesApp.service.ServidorService;

/**
 *
 * @author jessi
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new ServidorService();
    }
    
}
